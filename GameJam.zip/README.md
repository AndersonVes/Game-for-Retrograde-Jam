# T-rex of Fire

This game was developed for the game jam "[Retrograde Jam](https://itch.io/jam/retrograde-jam)". And it aims to provide an SNES game experience.

You are a dinosaur and must escape from some evil cyborgs-dinos. That's it, good luck. Ammunition is on us.

The game's resolution is 256x224, for a more nostalgic experience. And the music, mechanics, programming and sprites are 100% produced by Anderson and Bruno.
