function pauseAudios(final) {
    jumpAudio.pause();
    wavePassedAudio.pause();
    shootAudio.pause();
    collisionAudio.pause();
    bgAudio.pause();
    enemyDieAudio.pause();
}